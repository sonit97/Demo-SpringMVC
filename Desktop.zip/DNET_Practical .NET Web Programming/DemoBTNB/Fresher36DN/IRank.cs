﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fresher36DN
{
    interface IRank
    {
        //static string abc;
        // Khai báo prototype hàm xếp loại
         string Ranking(float score);
        // void showInfor();
        //public abstract void abc();
        //public virtual void abd
       
    }

    interface TeamBuilding
    {
        string Ranking(float score);

    }
    class ABC
    {
      /*  static void Main(string[] args)
        {
          /*  // Khai báo đối tượng của class
            Apolo apolo = new Apolo();
            University university = new University();

            // Gọi hàm xếp loại tương ứng với từng đối tượng
            Console.WriteLine("Apolo: " + apolo.Ranking(85));
            string xl = university.getRank();
            Console.WriteLine("University: " + xl);

            Console.ReadKey();*/
          
      //  }

    }
    
}
