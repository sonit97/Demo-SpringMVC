﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fresher36DN
{
    class ManagementStudent
    {
        static void Main(string[] args)
        {
            List<Students> ds = new List<Students>();

            Console.WriteLine("nhap ho ten");
            string ht = Console.ReadLine();
            Console.WriteLine("nhap tuoi");
            int t =Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("nhap dia chi");
            string dc = Console.ReadLine();

            //create object instance 
            Students st1 = new Students(ht, t, dc);
            Students st2 = new Students("tien", 15, "Da nang");
            Students st3 = new Students("Tu", 20, "Quang Nam");
            ds.Add(st1);
            ds.Add(st2);
            ds.Add(st3);

            ds.Sort(new StudentTuoiComparer());
            foreach (var item in ds)
            {
                Console.WriteLine(item.HoTen1 + ":" + item.Tuoi1+":"+item.DiaChi1);
            }

            Console.ReadLine();
        }
    }

   public class Students 
    {
        private string HoTen;

        public string HoTen1
        {
            get { return HoTen; }
            set { HoTen = value; }
        }
        private int Tuoi;

        public int Tuoi1
        {
            get { return Tuoi; }
            set { Tuoi = value; }
        }
        private string DiaChi;

        public string DiaChi1
        {
            get { return DiaChi; }
            set { DiaChi = value; }
        }

        public Students()
        { 
        }

        public Students(string _HoTen, int _Tuoi, string _DiaChi)
        {
            this.HoTen = _HoTen;
            this.Tuoi = _Tuoi;
            this.DiaChi = _DiaChi;
        }

       

    }
    public class StudentTuoiComparer : IComparer<Students>
    {
        public int Compare(Students x, Students y)
        {
            return x.Tuoi1.CompareTo(y.Tuoi1);
        }
    }

    public class StudentHoTeComparer : IComparer<Students>
    {
        public int Compare(Students x, Students y)
        {
            return x.HoTen1.CompareTo(y.HoTen1);
        }
    }
}
