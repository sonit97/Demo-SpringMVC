﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fresher36DN
{
    class DemoAbstract
    {
        class Program
        {
          /*  static void Main(string[] args)
            {
                // abstract class không thể tạo ra được đối tượng,
                // mà phải thông qua lớp conkế thừa từ nó
                // SAI.
                //Animal animal = new Animal();
                // Error: Cannot create an instance of the abstract class or interface 'Animal'

                // ĐÚNG
                Animal cat = new Cat();

                // hoặc:
                Cat cat1 = new Cat();

                Cow cow = new Cow();

                // Gọi các phương thức
                cat.Eat();
                cow.Eat();

                cat.AnimalSound();
                cow.AnimalSound();

                cat.Run();
                cat.Run();

                Console.ReadKey();
            }*/
        }

        // Khai báo abstract class
        public abstract class Animal
        {
            // abstract method
            public abstract void AnimalSound();

            // virtual method
            public virtual void Eat()
            {
                Console.WriteLine("Động vật ăn cỏ.");
            }

            // normal method
            public void Run()
            {
                Console.WriteLine("Chạy bằng 4 chân.");
            }
        }

        // Lớp Cat kế thừa lớp Animal
        public class Cat : Animal
        {
            // abstract method: bắt buộc lớp con phải override lại từ lớp cha.
            // Khi override thì phạm vi truy cập phải giống của lớp cha: public
            public override void AnimalSound()
            {
                Console.WriteLine("Mèo meow meow.");
            }

            // virtual method: việc override thì không bắt buộc.
            // Lớp con có thể dùng luôn định nghĩa từ lớp cha nếu phù hợp,
            // hoặc override (định nghĩa lại) nếu không phù hợp.
            // Khi override thì phạm vi truy cập phải giống của lớp cha: public
            public override void Eat()
            {
                Console.WriteLine("Mèo ăn cá.");
            }

            // normal method Run() thì dùng luôn của lớp cha không phải làm gì.
        }

        // Lớp Cow kế thừa lớp Animal
        public class Cow : Animal
        {
            public override void AnimalSound()
            {
                Console.WriteLine("Bò ummuu bò.");
            }
        }

    }
}
