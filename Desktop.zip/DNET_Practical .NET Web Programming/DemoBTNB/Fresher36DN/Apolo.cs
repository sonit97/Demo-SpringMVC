﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fresher36DN
{
    class Apolo:IRank
    {
        // Định nghĩa hàm Ranking
        // theo quy tắc xếp loại của trung tâm
        public string Ranking(float score)
        {
            if (score >= 85)
            {
                return "Distinction";
            }
            if (score >= 65)
            {
                return "Credit";
            }
            if (score >= 40)
            {
                return "Pass";
            }
            return "Fail";
        }


    }
}
