﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fresher36DN
{
    class University:IRank, TeamBuilding
    {
        // Định nghĩa hàm Ranking
        // theo quy tắc xếp loại của trường đại học
         string IRank.Ranking(float score)
        {
            if (score >= 3.6)
            {
                return "Xuat sac";
            }
            if (score >= 3.2)
            {
                return "Gioi";
            }
            if (score >= 2.5)
            {
                return "Kha";
            }
            if (score >= 2.0)
            {
                return "Trung Binh";
            }
            return "Khong xep loai";
        }


         string TeamBuilding.Ranking(float score)
         {
             if (score >= 3.6)
             {
                 return "Xuat sac";
             }
             if (score >= 3.2)
             {
                 return "Gioi";
             }
             if (score >= 2.5)
             {
                 return "Kha";
             }
             if (score >= 2.0)
             {
                 return "Trung Binh";
             }
             return "Khong xep loai";
         }
         public string getRank()
         {
             IRank uni;
             uni = this;

             return uni.Ranking(40);
         }
    }
}
