﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fresher36DN
{
    abstract class BaoHiem
    {
        DateTime TGBatDau;
        string TenBaoHiem;
        int SoThangToiThieu;
        public BaoHiem()
        {

        }
        public BaoHiem(DateTime tgbd)
        {

        }
    }

    class BaoHiemSinhKy : BaoHiem
    {
        DateTime TGKetThuc;
    }

    class BaoHiemTheoTGHopDong : BaoHiem
    {
        DateTime TGKetThuc;
        string DichVuDiKem;
    }

    class KhachHang
    {
        string HoTen;
        DateTime NgaySinh;
        BaoHiem bh;

        public KhachHang(string ht, DateTime ns, BaoHiem h)
        {
            this.HoTen = ht;
            this.NgaySinh = ns;
            this.bh = h;
        }
    }
    class Program
    {
       /* static void Main(string[] args)
        {

            BaoHiem bh = new BaoHiemSinhKy();

            string hoten = Console.ReadLine();
            DateTime dt = new DateTime("");

            KhachHang kh = new KhachHang()
        }*/
    }
}

