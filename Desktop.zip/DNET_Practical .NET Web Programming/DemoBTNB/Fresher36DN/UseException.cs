﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fresher36DN
{
   /* class UseException
    {
        
        public void DivZero()
        {
            try
            {

                int x = 5;
                int div = 0;

                try
                {
                    div = 100 / x;
                    //throw new DivideByZeroException("Invalid Division");
                    if (File.Exists("a.txt"))
                    {
                        // Open
                        StreamReader input = new StreamReader("a.txt");
                        StreamWriter output = new StreamWriter("b.txt");
                        // Repeat access until end of input
                        string line;
                        while ((line = input.ReadLine()) == null)
                        {
                            output.WriteLine(line);
                        }
                    }
                }
                catch (DivideByZeroException e)
                {
                    Console.WriteLine(e);

                }
                catch (IOException e)
                {
                    System.Console.WriteLine(e.Message);
                }

                finally
                {

                    throw new DivideByZeroException("Invalid Division");
                }
                //statement
            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.);
            }
           
        }

        public void DivZero1()
        {
            int x = 0;
            int div = 0;

            if (x == 0)
            {
                div = 100 / x;
                throw new DivideByZeroException("Invalid Division");
            }

            Console.WriteLine("LAST STATEMENT");
        }

       /* static void Main(string[] args)
        {
            Console.WriteLine("enter email");
            string em = Console.ReadLine();
            UseUserExxceprion use = new UseUserExxceprion();
            try
            {
                use.checkEmail(em);
            }
            catch (EmailExxception e)
            {
                Console.WriteLine(e);
            }
            Console.ReadKey();
           /*try
            {
                UseException use = new UseException();
                use.DivZero();
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("nhan exception tu DAO");
            }
            
            UseException use = new UseException();
            use.DivZero();
            Console.ReadLine();

        }*/
    }

    class EmailExxception : Exception
    {
        public EmailExxception(string str)
        {
            Console.WriteLine("Invalid Email");
        }
        public EmailExxception()
        { }
    }

    class UseUserExxceprion
    {
        public void checkEmail(string email)
        {
            //string pattern = ".....";
            if (email == "") 
                throw new EmailExxception();
        }

         /* static void Main(string[] args)
          {
              Console.WriteLine("enter email");
              string em =Console.ReadLine();
              UseUserExxceprion use = new UseUserExxceprion();
              try
              {
                  use.checkEmail(em);
              }
              catch (EmailExxception e)
              {
                  Console.WriteLine(e);
              }
              Console.ReadKey();
            
          }
    }*/
}
