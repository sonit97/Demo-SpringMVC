﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fresher36DN
{
    public delegate void ClickHandler();
    public delegate void MouseHandler();
    public class Button
    {
        public event ClickHandler onClick;
        public void PhatRaSuKienDangBiClick()
        {
            if (onClick != null)
            {
                Console.WriteLine("Nguoi dung dang click");
                onClick();
            }
            else
            {
                Console.WriteLine("ok");
            }
        }

    }

    public class Form
    {
        public void DangKyLangNgheSuKien(Button button)
        {
            button.onClick += new ClickHandler(this.CongViecThucHienKhiButtonClick);
        }
        public void CongViecThucHienKhiButtonClick()
        {
            Console.WriteLine("Hi ban!");
        }
    }

    class ActionButton
    {
        /* static void Main(string[] args)
         {
             Button buttonA = new Button();
             Form formB = new Form();

             //đăng ký sự kiện click lên button A
             formB.DangKyLangNgheSuKien(buttonA);
             //click lên button A
             buttonA.PhatRaSuKienDangBiClick();

             //action công việc 
             Console.ReadLine();
         }*/
    }

    public delegate void TinhToan(float num1, float num2);
    class Maths
    {
        public static void Cong(float a, float b)
        {
            float c = a + b;
            Console.WriteLine("Tong la {0}", c);
        }
        public static void Tru(float a, float b)
        {
            float c = a - b;
            Console.WriteLine("Hieu la {0}", c);
        }

        public static void Nhan(float a, float b)
        {
            float c = a * b;
            Console.WriteLine("Tich la {0}", c);
        }

        /* static void Main(string[] args)
         {
             TinhToan tt = new TinhToan(Cong);
             tt += new TinhToan(Tru);
             tt += new TinhToan(Nhan);

            // Console.WriteLine();
             tt(40, 30);
             Console.ReadLine();
         }*/
    }

    //generic
    interface IMaths<T>
    {
        T Addition(T valOne, T valTwo);
        T Subtraction(T valOne, T valTwo);
    }

    class Numbers : IMaths<float>
    {
        public float Addition(float valOne, float valTwo)
        {
            return valOne + valTwo;
        }
        public float Subtraction(float valOne, float valTwo)
        {
            if (valOne > valTwo)
            {
                return (valOne - valTwo);
            }
            else
            {
                return (valTwo - valOne);
            }
        }

    }

    class SwapNumbers
    {
        static void Swap<T>(ref T valOne, ref T valTwo)
        {
            T temp = valOne;
            valOne = valTwo;
            valTwo = temp;
        }
         void Main(string[] args) {
             int numOne = 23;
             int numTwo = 45;
             Console.WriteLine("Values before swapping: " + numOne + " & " + numTwo);
             Swap<int>(ref numOne, ref numTwo);
             Console.WriteLine("Values after swapping: " + numOne + " & " + numTwo);
             Console.ReadLine();
         }
       
    }

    class General<T>
    {
        T[] values;
        int _counter = 0;

        public General(int max)
        {
            values = new T[max];
        }

        public void Add(T val)
        {
            if (_counter < values.Length)
            {
                values[_counter] = val;
                _counter++;
            }
        }
        public void Display()
        {
            Console.WriteLine("Constructed Class is of type: " + typeof(T));
            Console.WriteLine("Values stored in the object of constructed class are: ");
            for (int i = 0; i < values.Length; i++)
            {
                Console.WriteLine(values[i]);
            }
        }

       
    }
}