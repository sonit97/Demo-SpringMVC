﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fresher36DN
{
    class DemoGeneric
    {
    }

    class General1<T>
    {
        T[] values;
        int _counter = 0;

        public General1(int max)
        {
            values = new T[max];
        }

        public void Add(T val)
        {
            if (_counter < values.Length)
            {
                values[_counter] = val;
                _counter++;
            }
        }
        public void Display()
        {
            Console.WriteLine("Constructed Class is of type: " + typeof(T));
            Console.WriteLine("Values stored in the object of constructed class are: ");
            for (int i = 0; i < values.Length; i++)
            {
                Console.WriteLine(values[i]);
            }
        }

        static void Main(string[] args)
        {
            General1<int> gl = new General1<int>(5);
            for (int i = 0; i < gl.values.Length; i++)
            {
                gl.Add(i + 1);
            }

            gl.Display();
        }
    }
}
