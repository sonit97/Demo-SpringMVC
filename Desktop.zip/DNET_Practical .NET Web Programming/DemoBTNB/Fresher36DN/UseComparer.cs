﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fresher36DN
{
    class UseComparer
    {
    }

    
    public class PersonAgeComparer : IComparer<Person>
    {
       public int Compare(Person x, Person y){
         return x.Age.CompareTo(y.Age);
       }
    }
    public class PersonNameComparer : IComparer<Person>
    {
       public int Compare(Person x, Person y){
         return x.Name.CompareTo(y.Name);
       }
    }

    /*  public class ListDemo
     {
        public static void Main(){
         List<Person> personList = new List<Person>();
         personList.Add(new Person{Age=10, Name="John"});
         personList.Add(new Person{Age=15, Name="Ann"});
         personList.Add(new Person{Age=8, Name="Kevin"});
         personList.Sort(new PersonAgeComparer());
         foreach (var item in personList){
           Console.WriteLine(item.Name + ":" + item.Age);
         }
         Console.ReadKey(true);
       }
     }*/
}
