﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fresher36DN
{
    class Dictionary
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> objDictionary = new Dictionary<int, string>();
            objDictionary.Add(201, "Gear Box");
            objDictionary.Add(220, "Oil Filter");
            objDictionary.Add(330, "Engine");
            objDictionary.Add(305, "Radiator");
            objDictionary.Add(303, "Steering");
            Console.WriteLine("Dictionary class contains values of type");
            Console.WriteLine(objDictionary.GetType());
            Console.WriteLine("Keys \t\t Values");
            Console.WriteLine("__________________________");
            IDictionaryEnumerator objDictionayEnumerator = objDictionary.GetEnumerator();
            while (objDictionayEnumerator.MoveNext())
            {
                Console.WriteLine(objDictionayEnumerator.Key.ToString()+ "\t\t" + objDictionayEnumerator.Value);
            }
        }
    }
    


public class ListDemo
{
    public static void Main(){
    List<Person> personList = new List<Person>();
    personList.Add(new Person{Age=10, Name="John"});
    personList.Add(new Person{Age=15, Name="Ann"});
    personList.Add(new Person{Age=8, Name="Kevin"});
    personList.Sort(); //Lỗi runtime ở đây
    foreach (var item in personList){
      Console.WriteLine(item.Name + ":" + item.Age);
    }
    Console.ReadKey(true);
  }
}
    

public class Person : IComparable<Person>
{
   public int Age {get;set;}
   public string Name{get;set;}
   public int CompareTo(Person other){
      return this.Age.CompareTo(other.Age);
   }
}
}
