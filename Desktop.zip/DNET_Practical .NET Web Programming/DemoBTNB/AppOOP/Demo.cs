﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;


namespace AppOOP
{
    class Demo
    {
        static void Main(string[] args)
        {
            
           /* Console.WriteLine("Nhap mot so");
            int num = Convert.ToInt32(Console.ReadLine());
            Demo d = new Demo();
            try
            {
                d.checkNumber(num);
            }
            catch (CheckNumberExceptions ex)
            {
                Console.WriteLine(ex);
            }

            Console.ReadKey();*/


string emailpattern = @"\w+(.\w+)*@\w+.(\w{2,})(.\w{2,})*";
Regex regx = new Regex(emailpattern);

string email = "fwa.ctc@fsoft.com.vn";
bool b = regx.IsMatch(email);   // Ignore the position
Console.WriteLine("b:{0}",b);
Match m = regx.Match(email);    // get more information
Console.WriteLine("m:{0}", m);

b = m.Success;                  // true
Console.WriteLine("b:{0}", b);

int i = m.Index;              // the position of the 1st matched character
Console.WriteLine("i:{0}", i);

string textfound = m.Value;     // "fwa.ctc@fsoft.com.vn" in this case
Console.WriteLine("textfound:{0}", textfound);


/*email = "fwa@fsoft.com.vn, fpt@fsoft.com.vn";
MatchCollection ms = regx.Matches(email); // multiple results
foreach (Match m1 in ms){
   i         = m1.Index;        // 0 then 18
   textfound = m1.Value;        // fwa@fsoft.com.vn then fpt@fsoft.com.vn
                                // m1.Success is always true in collection

// Removes whitespace between a word character and . or ,
Regex rgx = new Regex(@"(\w)(\s+)([.,])");
string s = rgx.Replace("sdfd . sdfgdg ,", @"$1$3");*/
Console.ReadKey();

    }

        
        public void chia()
        {
            int x = 0;
            int div = 0;

            if (x == 0)
            {
                div = 100 / x;
                throw new DivideByZeroException("Invalid!");
            }
        }

        public void checkNumber(int x)
        {
            if (x < 0)
                throw new CheckNumberExceptions();
        }
    }

    class CheckNumberExceptions : Exception
    {
        public CheckNumberExceptions()
        {
            Console.WriteLine("invalid number");
        }

    }
}
