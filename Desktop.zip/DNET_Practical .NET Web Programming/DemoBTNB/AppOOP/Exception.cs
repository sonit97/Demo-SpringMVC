﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppOOP
{
    class CheckNumberException:Exception
    {
        public CheckNumberException(string str)
        {
            Console.WriteLine("Number format Exception");
        }
    }

    class UseUserExxceprion
    {
        public void checkNumber(int number)
        {
            if (number < 100) throw new CheckNumberException("number format not valid!");
        }

      /*  static void Main(string[] args)
        {
            Console.WriteLine("enter number");
            int num =Convert.ToInt32(Console.ReadLine());
            UseUserExxceprion use = new UseUserExxceprion();
            try
            {
                use.checkNumber(num);
            }
            catch (CheckNumberException e)
            {
                Console.WriteLine(e);
            }
            Console.ReadKey();
            
        }*/
    }
    class MyClient
    {
        public void DivZero()
        {
            int x = 0;
            int div = 0;

            try
            {
                div = 100 / x;
                //throw new DivideByZeroException("Invalid Division");
            }
            catch (DivideByZeroException e)
            {
                Console.WriteLine(e);
            }
            Console.WriteLine("LAST STATEMENT");
        }

        public void DivZero1()
        {
            int x = 0;
            int div = 0;

             if(x==0)
             {
                div = 100 / x;
                throw new DivideByZeroException("Invalid Division");
             }
            
            Console.WriteLine("LAST STATEMENT");
        }


        /*static void Main(string[] args)
        {
            MyClient myclient = new MyClient();
           // try
           // {
                myclient.DivZero1();
          //  }
          //  catch (DivideByZeroException e)
          //  {
           //     Console.WriteLine(e);
          //  }
            Console.ReadKey();
        }*/

        class abc
        { 
        }
    } 

}
