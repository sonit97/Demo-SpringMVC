﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppOOP
{
    class Program
    {
        
    }
    abstract class Candidate
    {
        string hoten;
        DateTime ngaysinh;
        string email;
 
    }

    class Certificate
    {
        string id;
        string tencc;
        string truongcap;
 
    }
    class Fresher : Candidate
    {
        int namTN;
        Certificate cer;

        internal Certificate Cer
        {
            get { return cer; }
            set { cer = value; }
        }
        public Fresher()
        {
 
        }
    }
}
