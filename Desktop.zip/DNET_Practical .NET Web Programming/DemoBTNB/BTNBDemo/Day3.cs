﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTNBDemo
{

    #region Delegates
    public delegate int Calculation(int numOne, int numTwo);
    class Mathematics
    {
        static int Addition(int numOne, int numTwo)
        {
            return (numOne + numTwo);
        }
        static int Subtraction(int numOne, int numTwo)
        {
            return (numOne - numTwo);
        }
        /*static void Main(string[] args)
        {
            int valOne = 5;
            int valTwo = 23;
            Calculation objCalculation = new Calculation(Addition);
            Console.WriteLine (valOne + " + " + valTwo + " =" +objCalculation (valOne, valTwo));
            Console.ReadKey();
        }*/

    }

    //Multiple Delegates
    public delegate double CalculateArea(double val);
    public delegate double CalculateVolume(double val);
    class Cube
    {
        static double Area(double val)
        {
            return 6 * (val * val);
        }
        static double Volume(double val)
        {
            return (val * val);
        }
        /*static void Main(string[] args)
        {
            CalculateArea objCalculateArea = new CalculateArea(Area);
            CalculateVolume objCalculateVolume = new
            CalculateVolume(Volume);
            Console.WriteLine("Surface Area of Cube: " +
            objCalculateArea(200.32));
            Console.WriteLine("Volume of Cube: " +
            objCalculateVolume(20.56));
        
    }*/

        //Multicast Delegates
        public delegate void Maths(int valOne, int valTwo);
        class MathsDemo
        {
            static void Addition(int valOne, int valTwo)
            {
                int result = valOne + valTwo;
                Console.WriteLine("Addition: " + valOne + " + " +
                valTwo + "= " + result);
            }
            static void Subtraction(int valOne, int valTwo)
            {
                int result = valOne - valTwo;
                Console.WriteLine("Subtraction: " + valOne + " - " +
                valTwo + "= " + result);
            }
            static void Multiplication(int valOne, int valTwo)
            {
                int result = valOne * valTwo;
                Console.WriteLine("Multiplication: " + valOne + " * "
                + valTwo + "= " + result);
            }
            static void Division(int valOne, int valTwo)
            {
                int result = valOne / valTwo;
                Console.WriteLine("Division: " + valOne + " / " +
                valTwo + "= " + result);
            }
           /* static void Main(string[] args)
            {
                Maths objMaths = new Maths(Addition);
                objMaths += new Maths(Subtraction);
                objMaths += new Maths(Multiplication);
                objMaths += new Maths(Division);
                if (objMaths != null)
                {
                    objMaths(20, 10);
                }
                Console.ReadKey();
            }*/

        }

        //System.Delegate Class
        public delegate void Messenger(int value);
        class CompositeDelegates
        {
            /// <summary>
            /// even numbers
            /// </summary>
            /// <param name="value"></param>
            static void EvenNumbers(int value)
            {
                Console.Write("Even Numbers: ");
                for (int i = 2; i <= value; i += 2)
                {
                    Console.Write(i + " ");
                }
            }

            /// <summary>
            /// odd numbers
            /// </summary>
            /// <param name="value"></param>
            void OddNumbers(int value)
            {
                Console.WriteLine();
                Console.Write("Odd Numbers: ");
                for (int i = 1; i <= value; i += 2)
                {
                    Console.Write(i + " ");
                }
            }

            /// <summary>
            /// start 
            /// </summary>
            /// <param name="number"></param>
            static void Start(int number)
            {
                CompositeDelegates objComposite = new CompositeDelegates();
                Messenger objDisplayOne = new Messenger(EvenNumbers);
                Messenger objDisplayTwo = new Messenger(objComposite.OddNumbers);
                Messenger objDisplayComposite = (Messenger)Delegate.Combine(objDisplayOne, objDisplayTwo);
                objDisplayComposite(number);
                Console.WriteLine();
                Object obj = objDisplayComposite.Method.ToString();
                if (obj != null)
                {
                    Console.WriteLine("The delegate invokes an instancemethod: " + obj);
                }
                else
                {
                    Console.WriteLine("The delegate invokes only static methods");
                }
            }

            /* static void Main(string[] args)
             {
                 int value = 0;
                 Console.WriteLine("Enter the values till which you want to display even and odd numbers");
                 try
                 {
                     value = Convert.ToInt32(Console.ReadLine());
                 }
                 catch (FormatException objFormat)
                 {
                     Console.WriteLine("Error: " + objFormat);
                 }
                 Start(value);
                 Console.ReadKey();
             }*/
        }

    #endregion

        #region Event
        public delegate void PrintDetails();
        class TestEvent
        {
            event PrintDetails Print;

            /// <summary>
            /// show method
            /// </summary>
            void Show()
            {
                Console.WriteLine("This program illustrate how to subscribe objects to an event");
                Console.WriteLine("This method will not execute since the event has not been raised");
            }

            /// <summary>
            /// main method
            /// </summary>
            /// <param name="args"></param>
            /*static void Main(string[] args)
            {
                TestEvent objTestEvent = new TestEvent();
                objTestEvent.Print += new PrintDetails(objTestEvent.Show);
            }*/

        }

        //Events and Inheritance
        public delegate void Display(string msg);
        public class Parent
        {
            event Display Print;
            protected void InvokeMethod()
            {
                Print += new Display(PrintMessage);
                Check();
            }
            void Check()
            {
                if (Print != null)
                {
                    PrintMessage("Welcome to C#");
                }
            }
            void PrintMessage(string msg)
            {
                Console.WriteLine(msg);
            }
        }
        class Child : Parent
        {
            /* static void Main(string[] args)*/
        }
        #endregion



    }

    namespace EventExample
    {
        public delegate void ClickHandler();

        public class Button
        {
            public event ClickHandler onClick;
            public void PhatRaSuKienDangBiClick()
            {
                if (onClick != null)
                {
                    Console.WriteLine("Nguoi dung dang click");
                    onClick();
                }
                else
                {
                    Console.WriteLine("ok");
                }
            }

        }

        public class Form
        {
            public void DangKyLangNgheSuKien(Button button)
            {
                button.onClick += new ClickHandler(this.CongViecThucHienKhiButtonClick);
            }
            public void CongViecThucHienKhiButtonClick()
            {
                Console.WriteLine("Hi ban!");
            }
        }

        class Program
        {
             /*static void Main(string[] args)
             {
                 Button buttonA = new Button();
                 Form formB = new Form();

                 //đăng ký sự kiện click lên button A
                 formB.DangKyLangNgheSuKien(buttonA);
                 //click lên button A
                 buttonA.PhatRaSuKienDangBiClick();

                 //action công việc thực hiện
                 Console.ReadLine();
             }*/
        }
    }
}