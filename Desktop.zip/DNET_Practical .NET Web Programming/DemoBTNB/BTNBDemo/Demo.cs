﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTNBDemo
{
    class Demo
    {
       /*    static void Main(string[] args)
        {
            //Car car1 = new Car();
            Console.WriteLine("Enter ID:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter number of wheel:");
            int wheel = Convert.ToInt32((Console.ReadLine()));
            Console.WriteLine("Enter color of car:");
            string color = Console.ReadLine();
            Console.WriteLine("enter product:");
            string product = Console.ReadLine();

            // Car car2 = new Car(id, wheel, color, product);

            Car car1 = new Car();
            car1.Id = id;
            car1.Wheels = wheel;
            car1.Color = color;
            car1.Product = product;
            car1.showInfor();
            //Console.WriteLine("id:{0}", car1.Id);
            Console.ReadKey();
        }*/


        class Car
        {
            private int _Id;

            public int Id
            {
                get { return _Id; }
                set { _Id = value; }
            }
            private int _wheels;

            public int Wheels
            {
                get { return _wheels; }
                set { _wheels = value; }
            }
            private string _color;

            public string Color
            {
                get { return _color; }
                set { _color = value; }
            }
            private string _product;

            public string Product
            {
                get { return _product; }
                set { _product = value; }
            }

            public Car()
            {
                //this._Id = 123;

            }

            public Car(int id, int wheels, string color, string product)
            {
                this._Id = id;
                this._wheels = wheels;
                this._color = color;
                this._product = product;
            }

            ~Car()
            {
                Console.WriteLine("removed!");
            }


            /// <summary>
            /// show information ...
            /// </summary>
            public void showInfor()
            {
                Console.WriteLine("Id:{0}\n Wheel:{1}\nColor:{2}\n product:{3}", this.Id, this.Wheels, this.Color, this.Product);
            }
        }
    }
}