﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTNBDemo
{
    class Day3
    {
    }

    #region System.Collections
    class Employee : DictionaryBase
    {
        /// <summary>
        /// add
        /// </summary>
        /// <param name="id"></param>
        /// <param name="name"></param>
        public void Add(int id, string name)
        {
            Dictionary.Add(id, name);
        }

        /// <summary>
        /// on remove
        /// </summary>
        /// <param name="id"></param>
        public void OnRemove(int id)
        {
            Console.WriteLine("You are going to delete record containing ID: " + id);
            Dictionary.Remove(id);
        }

        /// <summary>
        /// get details
        /// </summary>
        public void GetDetails()
        {
            IDictionaryEnumerator objEnumerate = Dictionary.GetEnumerator();
            while (objEnumerate.MoveNext())
            {
                Console.WriteLine(objEnumerate.Key.ToString() +"\t\t" +objEnumerate.Value);
            }
        }

        /*static void Main(string[] args)
        {
            Employee objEmployee = new Employee();
            objEmployee.Add(102, "John");
            objEmployee.Add(105, "James");
            objEmployee.Add(106, "Peter");
            Console.WriteLine("Original values stored in Dictionary");
            objEmployee.GetDetails();
            objEmployee.OnRemove(106);
            Console.WriteLine("Modified values stored in Dictionary");
            objEmployee.GetDetails();
            Console.ReadKey();
        }*/
    }


    class Customer
    {
        private int _id;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public Customer(int id, string name)
        {
            this._id = id;
            this._name = name;
        }

        public void showInfor()
        {
            Console.WriteLine("Id:{0} \n Name:{1}",this.Id, this.Name);
        }
    }
    class Program
    {
       /* void Main(string[] args)
        {
           int choose = 1;
           Customer cus1;
           ArrayList objCustomers = new ArrayList();

           //add new customer
           do
           {
               Console.WriteLine("id:");
               int Id = Convert.ToInt32(Console.ReadLine());
               Console.WriteLine("name:");
               string Name = Console.ReadLine();

               //create instance of Customer
                cus1= new Customer(Id, Name);
               objCustomers.Add(cus1);

               Console.WriteLine("co muon nhap tiep hay khong");
               choose = Convert.ToInt32(Console.ReadLine());
           } while (choose == 1);

            /*objCustomers.Add("Nicole Anderson");
            objCustomers.Add("Ashley Thomas");
            objCustomers.Add("Garry White");

            Console.WriteLine("Fixed Size : " + objCustomers.IsFixedSize);
            Console.WriteLine("Count : " + objCustomers.Count);
            Console.WriteLine("List of customers:");

           for (int i = 0; i < objCustomers.Count; i++)
           {
              
           }
            foreach (Customer cus in objCustomers)
            {
                cus.showInfor();
            }

            objCustomers.Sort();
            Console.ReadLine();

            Console.WriteLine("\nList of customers after sorting:");
            foreach (string names in objCustomers)
            {
                Console.WriteLine("{0}", names);
            }

            objCustomers.Reverse();
            Console.WriteLine("\nList of customers after reversing:");
            foreach (string names in objCustomers)
            {
                Console.WriteLine("{0}", names);
            }

            objCustomers.Clear();
            Console.WriteLine("Count after removing all elements : " + objCustomers.Count
        }*/
    }

    //Hashtable
    class Authors
    {
        /*static void Main(string[] args)
        {
            Hashtable objAuthors = new Hashtable();

            objAuthors.Add("AU01","John");
            objAuthors.Add("AU04", "Mary");
            objAuthors.Add("AU09", "William");
            objAuthors.Add("AU11", "Rodrick");

            Console.WriteLine("Read-only : " + objAuthors.IsReadOnly);
            Console.WriteLine("Count : " + objAuthors.Count);
            IDictionaryEnumerator objCollection = objAuthors.GetEnumerator();

            Console.WriteLine("List of authors:\n");
            Console.WriteLine("Author ID \t Name");
            while(objCollection.MoveNext())
            {
                Console.WriteLine(objCollection.Key + "\t\t " +objCollection.Value);
            }
            if(objAuthors.Contains("AU01"))
            {
                Console.WriteLine("\nList contains author with id AU01");
            }
            else
            {
                Console.WriteLine("\nList does not contain author with id AU01");
            }
            Console.ReadLine();
        }*/
    }

    //SortedList
    class SortedCollection
    {
       /* static void Main(string[] args)
        {
            SortedList objSortList = new SortedList();

            objSortList.Add("John", "Administration");
            objSortList.Add("Anny", "K Resources");
            objSortList.Add("Peter", "Finance");
            objSortList.Add("Joel", "Marketing");

            Console.WriteLine("Original values stored in the sorted list");
            Console.WriteLine("Key \t\t Values");
            for (int i=0; i<objSortList.Count; i++)
            {
                Console.WriteLine(objSortList.GetKey(i) + " \t\t " +objSortList.GetByIndex(i));
            }

            if (!objSortList.ContainsKey("Jerry"))
            {
                objSortList.Add("Jerry", "Construction");
            }
            objSortList["Peter"] = "Engineering";
            objSortList["Jerry"] = "Information Technology";
            Console.WriteLine();
            Console.WriteLine("Updated values stored in hashtable");
            Console.WriteLine("Key \t\t Values");
            for (int i = 0; i < objSortList.Count; i++)
            {
                Console.WriteLine(objSortList.GetKey(i) + " \t\t " +objSortList.GetByIndex(i));
            }
            Console.ReadLine();
        }*/
    }

    //generic

   
    }
      
    class Students
    {
        /*static void Main(string[] args)*/
    }

    //generic method
    class SwapNumbers{
        static void Swap<T>(ref T valOne, ref T valTwo) {
            T temp = valOne;
            valOne = valTwo;
            valTwo = temp;
        }
      /* static void Main(string[] args) {
            int numOne = 23;
            int numTwo = 45;
            Console.WriteLine("Values before swapping: " + numOne + " & " + numTwo);
            Swap<int>(ref numOne, ref numTwo);
            Console.WriteLine("Values after swapping: " + numOne + " & " + numTwo);
            Console.ReadLine();
        }*/
    }

    //generic interface
    interface IMaths<T>{
        T Addition(T valOne, T valTwo);
        T Subtraction(T valOne, T valTwo);
    }

    class Numbers : IMaths<int>
    {
        public int Addition(int valOne, int valTwo)
        {
            return valOne + valTwo;
        }
        public int Subtraction(int valOne, int valTwo){
            if (valOne > valTwo){
                return (valOne - valTwo);
            }
            else{
                return (valTwo - valOne);
            }
        }
        /*static void Main(string[] args){
            int numOne = 23;
            int numTwo = 45;
            Numbers objInterface = new Numbers();
            Console.Write("Addition of two integer values is: ");
            Console.WriteLine(objInterface.Addition(numOne, numTwo));
            Console.Write("Subtraction of two integer values is: ");
            Console.WriteLine(objInterface.Subtraction(numOne, numTwo));
        }*/
    }

    //delegates generic
    delegate T DelMath<T>(T val);
    class Number
    {
        static int NumberType(int num)
        {
            if (num % 2 == 0)
                return num;
            else
                return (0);
        }
        static float NumberType(float num)
        {
            return num % 2.5F;
        }
        /*public static void Main(string[] args)
        {
            DelMath<int> objDel = NumberType;
            DelMath<float> objDel2 = NumberType;
            Console.WriteLine(objDel(10));
            Console.WriteLine(objDel2(108.756F));
        }*/
    }

    //generic iterator
    class GenericDepartment<T>
    {
        T[] item;
        public GenericDepartment(T[] val)
        {
            item = val;
        }
        public IEnumerator<T> GetEnumerator()
        {
            foreach (T value in item)
            {
                yield return value;
            }
        }
    }
    class GenericIterator
    {
        /*static void Main(string[] args)
        {
            string[] departmentNames = { "Marketing", "Finance","Information Technology", "Human Resources" };
            GenericDepartment<string> objGeneralName = new GenericDepartment<string>(departmentNames);
            foreach (string val in objGeneralName)
            {
                Console.Write(val + "\t");
            }

            int[] departmentID = { 101, 110, 210, 220 };
            GenericDepartment<int> objGeneralID = new  GenericDepartment<int>(departmentID);
            Console.WriteLine();
            foreach (int val in objGeneralID)
            {
                Console.Write(val + "\t\t");
            }
            Console.WriteLine();
        }*/
    }

    //Inumrable
    class NamedIterators
    {
        string[] cars = { "Ferrari", "Mercedes", "BMW", "Toyota", "Nissan"};
        public IEnumerable GetCarNames() {
            for (int i = 0; i < cars.Length; i++) 
            {
                yield return cars[i];
            }
        }
       /* static void Main(string[] args) 
        {
            NamedIterators objIterator = new NamedIterators();
            foreach (string str in objIterator.GetCarNames()) 
            {
                Console.WriteLine(str);
            }
            Console.ReadLine();
        }*/
    }
    #endregion
}
