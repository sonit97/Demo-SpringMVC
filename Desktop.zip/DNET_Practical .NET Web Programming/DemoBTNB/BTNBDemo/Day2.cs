﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTNBDemo
{
    class AccessModifier
    {
        /*private: một biến được chỉ ra private chỉ có thể được truy cập bởi các thành phần trong lớp đó.
protected: một biến được khai báo là protected chỉ có thể được truy cập bởi các thành phần bên trong lớp đó và các thành phần trong lớp kế thừa lớp đó.
internal: một biến internal có thể được truy cập bởi các thành phần trong 1 lớp, các thành phần trong lớp kế thừa, các thành phần trong các lớp cùng assembly với nó.
public: một biến là public thì có thể được truy cập bởi bất kì một thành phần của bất kì một lớp nào.*/
    }

    class Student
    {
        /// <summary>
        /// print name of student
        /// </summary>
        /// <param name="firstName"></param>
        /// <param name="lastName"></param>
        void printName(String firstName, String lastName)
        {
            Console.WriteLine("First Name = {0}, Last Name = {1}",firstName, lastName);
        }

       /* static void Main(string[] args)
        {
            Student student = new Student();
            //Passing argument by position
            student.printName("Henry", "Parker");
            //Passing named argument
            student.printName(firstName: "Henry", lastName: "Parker");
            student.printName(lastName: "Parker", firstName:
            "Henry");
            //Passing named argument after positional argument
            student.printName("Henry", lastName: "Parker");
        }*/
    }

#region Static class
    static class Product
    {
        static int _productId;
        static double _price;

        /// <summary>
        /// constructor
        /// </summary>
        static Product()
        {
            _productId = 10;
            _price = 156.32;
        }

        /// <summary>
        /// display product
        /// </summary>
        public static void Display()
        {
            Console.WriteLine("Product ID: " + _productId);
            Console.WriteLine("Product price: " + _price);
        }
    }

    class Medicine
    {
       /* static void Main(string[] args)
        {
            Product.Display();
        }*/
    }
#endregion

#region Static Methods
    class Calculate
    {
        /// <summary>
        /// addition two number
        /// </summary>
        /// <param name="val1"></param>
        /// <param name="val2"></param>
        public static void Addition(int val1, int val2)
        {
            Console.WriteLine(val1 + val2);
        }

        /// <summary>
        /// multiply two number
        /// </summary>
        /// <param name="val1"></param>
        /// <param name="val2"></param>
        public void Multiply(int val1, int val2)
        {
            Console.WriteLine(val1 * val2);
        } 
    }
    static class Methods
    {
        /*static void Main(string [] args)
        {
            Calculate.Addition(10, 50);
            Calculate objCal = new Calculate();
            objCal.Multiply(10, 20);
        } */
    }
#endregion

#region Constructors adn descontructor
    //Theo luật của C#, static constructor chỉ được gọi một lần duy nhất trong suốt chương trình
    class Employees
    {
        string _empName;
        int _empAge;
        string _deptName;


        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="name"></param>
        /// <param name="num"></param>
        Employees(string name, int num)
        {
            _empName = name;
            _empAge = num;
            _deptName = "Research & Development";
        }
        

        /// <summary>
        /// desconstructor
        /// </summary>
        ~Employees()
        {
            Console.WriteLine("removed object");
        }
       /* static void Main(string[] args)
        {
            Employees objEmp = new Employees("John", 10);
            Console.WriteLine(objEmp._deptName);
        }*/
    }  

#endregion

#region Inheritance 
    //Multi-level Hierarchy
    class Animal1
    {
        /// <summary>
        /// Eat
        /// </summary>
        public void Eat()
        {
            Console.WriteLine("Every animal eats something.");
        }
    }
    class Mammal : Animal1
    {
        /// <summary>
        /// features
        /// </summary>
        public void Feature()
        {
            Console.WriteLine("Mammals give birth to young ones.");
        }
    }
    class Dog : Mammal
    {
        /// <summary>
        /// noise
        /// </summary>
        public void Noise()
        {
            Console.WriteLine("Dog Barks.");
        }
       /* static void Main(string[] args)
        {
            Dog objDog = new Dog();
            objDog.Eat();
            objDog.Feature();
            objDog.Noise();
            Console.ReadKey();
        }*/
    }

    //Base Class Constructors
    class Metals
    {
        string _metalType;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="type"></param>
        public Metals(string type)
        {
            _metalType=type;
            Console.WriteLine("Metal:\t\t"+_metalType);
        } 
    }
    class SteelCompany : Metals
    {
        string _grade;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="grade"></param>
        public SteelCompany(string grade):base("Steel")
        {
            _grade=grade;
            Console.WriteLine("Grade:\t\t"+_grade);
        }
    }
    class Automobiles:SteelCompany
    {
        string _part;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="part"></param>
        public Automobiles(string part):base("CastIron")
        {
        _part=part;
        Console.WriteLine("Part:\t\t"+_part);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
      /*  static void Main(string[]args)
        {
            Automobiles objAutomobiles=new Automobiles("Chassies");
        }    */
    }

    //virtual and override
    class Animal2
    {
        /// <summary>
        /// 
        /// </summary>
        public virtual void Eat()
        {
            Console.WriteLine("Every animal eats something");
        }

        /// <summary>
        /// 
        /// </summary>
        protected void DoSomething()
        {
            Console.WriteLine("Every animal does something");
        }
    }
    class Cat : Animal2
    {
        //Class Cat overrides Eat()method of class Animal
        /// <summary>
        /// 
        /// </summary>
        public override void Eat()
        {
            Console.WriteLine("Cat loves to eat the mouse");
        }

       /* static void Main(String[] args)
        {
            Cat objCat = new Cat();
            objCat.Eat();
        }*/
    }
#endregion

#region Polymorphism
    class Area
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="len"></param>
        /// <param name="wide"></param>
        /// <returns></returns>
        static int CalculateArea(int len, int wide)
        {
            return len * wide;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="valOne"></param>
        /// <param name="valTwo"></param>
        /// <returns></returns>
        static double CalculateArea(double valOne, double valTwo)
        {
            return 0.5 * valOne * valTwo;
        }
       /* static void Main(string[] args)
        {
            int length = 10;
            int breadth = 22;
            double tbase = 2.5;
            double theight = 1.5;
            Console.WriteLine("Area of Rectangle: " + CalculateArea(length, breadth));
            Console.WriteLine("Area of triangle: " + CalculateArea(tbase, theight));
        }*/
    }
#endregion

#region Abstract Classes
    abstract class Animals
    {
        /// <summary>
        /// Eat
        /// </summary>
        public void Eat()
        {
            Console.WriteLine("Every animal eats food in order to survive");
        }
        public abstract void AnimalSound();
    }
   abstract class Lion : Animals
    {
       public abstract void Drink();
       
    }

   class Dog1 : Lion
   {
       public override void AnimalSound()
       {
           Console.WriteLine("hiss");
       }

       public override void Drink()
       { 
       }

       /* static void Main(string[] args)
        {
            Dog1 objLion = new Dog1();
            objLion.AnimalSound();
            objLion.Eat();
            Console.ReadLine();
        }*/
   }
#endregion

#region Interfaces
    interface ITerrestrialAnimal
    {
        /// <summary>
        /// Eat method
        /// </summary>
        void Eat();
    }
    interface IMarineAnimal
    {
        /// <summary>
        /// swim method
        /// </summary>
         void Swim();
    }
    class Crocodile : IMarineAnimal, ITerrestrialAnimal
    {
        public void Eat()
        {
            Console.WriteLine("The Crocodile eats flesh");
        }
        public void Swim()
        {
             Console.WriteLine("The Crocodile can swim four times faster than an Olympic swimmer");
        }
        /*static void Main(string[] args)
        {
            Crocodile objCrocodile = new Crocodile();
            objCrocodile.Eat();
            objCrocodile.Swim();
        }*/
    }

    //re-implement interface
    interface IMath
    {
        
        void Area();
    }
    class Circle : IMath
    {
        public const float PI = 3.14F;
        protected float Radius;
        protected double AreaOfCircle;

        /// <summary>
        /// area
        /// </summary>
        public virtual void Area()
        {
            AreaOfCircle = (PI * Radius * Radius);
        }
    }
    class Sphere : Circle
    {
        double _areaOfSphere;

        /// <summary>
        /// area - override to re-implementation
        /// </summary>
        public void Area()
        {
            base.Area();
            _areaOfSphere = (AreaOfCircle * 4);
        }
      /* static void Main(string[] args)
        {
            Sphere objSphere = new Sphere();
            objSphere.Radius = 7;
            objSphere.Area();
            Console.WriteLine("Area of Sphere: {0:F2}",
            objSphere._areaOfSphere);
        }*/
    }
#endregion

}
