﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTNBDemo
{
    class Program1
    {
        static void Main(string[] args)
        {
        }

        #region demoMethod

        /// <summary>
        /// addition
        /// </summary>
        /// <param name="val1"></param>
        /// <param name="val2"></param>
        public static void Addition(int val1, int val2)
        {
            Console.WriteLine(val1 + val2);
        }

        #endregion

    }
}
