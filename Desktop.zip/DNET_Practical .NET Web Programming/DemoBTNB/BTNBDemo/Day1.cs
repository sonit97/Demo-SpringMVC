﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTNBDemo
{
    class Day1
    {
       /* static void Main(string[] args)
        {
            Day1 d1 = new Day1();
            //d1.demoImplicitlyVariable();
            //d1.demoVariable();
            //d1.demoConstrant();
            //d1.demoInputData();
           // d1.demoMathOperator();
            Console.ReadKey();
        }*/
        #region Public Method

        /// <summary>
        /// sum of two number
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        public void sumNumber(int a, int b)
        {
            Console.WriteLine("Result:{0}",(a+b));
        }

        ///<summary>
        ///input data
        ///</summary>
        public void demoOperator()
        {
            //demo Math
            int valueOne = 10;
            int valueTwo = 2;
            int add = valueOne + valueTwo;
            int sub = valueOne - valueTwo;
            int mult = valueOne * valueTwo;
            int div = valueOne / valueTwo;
            int modu = valueOne % valueTwo;
            Console.WriteLine("Addition " + add );
            Console.WriteLine("Subtraction " + sub);
            Console.WriteLine("Multiplication " + mult);
            Console.WriteLine("Division " + div);
            Console.WriteLine("Remainder " + modu);

            //demo Relation
            int leftVal = 50;
            int rightVal = 100;
            Console.WriteLine("Equal: " + (leftVal == rightVal));
            Console.WriteLine("Not Equal: " + (leftVal != rightVal));
            Console.WriteLine("Greater: " + (leftVal > rightVal));
            Console.WriteLine("Lesser: " + (leftVal < rightVal));
            Console.WriteLine("Greater or Equal: " + (leftVal >= rightVal));
            Console.WriteLine("Lesser or Equal: " + (leftVal <= rightVal));

            //demo assignment
            int valueOne1 = 5;
            int valueTwo2 = 10;
            Console.WriteLine("Value1 =" + valueOne1);
            valueOne += 4;
            Console.WriteLine("Value1 += 4= " + valueOne1);
            valueOne -= 8;
            Console.WriteLine("Value1 -= 8= " + valueOne1);
            valueOne *= 7;
            Console.WriteLine("Value1 *= 7= " + valueOne1);
            valueOne /= 2;
            Console.WriteLine("Value1 /= 2= " + valueOne1);
            Console.WriteLine("Value1 == Value2: {0}", (valueOne1 == valueTwo2));

            //demo Precedence and Associativity
            int valueOne11 = 10;
            Console.WriteLine((4 * 5 - 3) / 6 + 7 - 8 % 5);
            Console.WriteLine((32 < 4) || (8 == 8));
            Console.WriteLine(((valueOne11 *= 6) > (valueOne11 += 5)) && ((valueOne11 /= 2) !=
            (valueOne11 -= 5)));

            

        }

        ///<summary
        ///demo String Operator
        ///</summary>
        public void demoStringOperator()
        {
            //String Concatenation
            int num = 6;
            string msg = "";
            if (num < 0)
            {
                msg = "The number " + num + " is negative";
            }
            else if ((num % 2) == 0)
            {
                msg = "The number " + num + " is even";
            }
            else
            {
                msg = "The number " + num + " is odd";
            }
            if (msg != "")
                Console.WriteLine(msg);
        }

        ///<summary>
        ///Boxing and Unboxing
        ///</summary>
        public void demoBoxingandUnboxing()
        {
            //boxing
            float radius = 4.5F;
            double circumference;
            circumference = 2 * 3.14 * radius;
            object boxed1 = (object)circumference;
            Console.WriteLine("Circumference {0} of the circle = ", circumference);

            //unboxing
            int length = 10;
            int breadth = 20;
            int area;
            area = length * breadth;
            object boxed2 = area;
            int num = (int)boxed2;
            Console.WriteLine("Area of the rectangle= {0}", num);
        }

        ///<summary>
        ///input data
        ///</summary>
        public void demoInputData()
        {
            string custName;
            double loanAmount;
            float interest = 0.09F;
            double interestAmount = 0;
            double totalAmount = 0;
            Console.Write("Enter the name of the customer : ");
            custName = Console.ReadLine();

            Console.Write("Enter loan amount : ");
            loanAmount = Convert.ToDouble(Console.ReadLine());

            interestAmount = loanAmount * interest;
            totalAmount = loanAmount + interestAmount;

            Console.WriteLine("\nCustomer {0} Name : ", custName);
            Console.WriteLine("Loan amount : ${0:#,###.#0} \nInterest rate :{1:0#%} \nInterest Amount : ${2:#,###.#0}",
            loanAmount, interest, interestAmount );
            Console.WriteLine("Total amount to be paid : ${0:#,###.#0} ",
            totalAmount);

            //convert data
            string userName;
            int age;
            double salary;
            Console.Write("Enter your name: ");
            userName = Console.ReadLine();
            Console.Write("Enter your age: ");
            age = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the salary: ");
            salary = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Name: {0}, Age: {1}, Salary: {2} ", userName, age, salary);

            //number format
            Console.WriteLine("Number format");
            int num = 456;
            Console.WriteLine("{0:C}", num);
            Console.WriteLine("{0:D}", num);
            Console.WriteLine("{0:E}", num);
        }

        ///<summary>
        ///Constrant
        ///</summary>
        public void demoConstrant()
        {
           const float _pi = 3.14F;
           float radius = 5;
           float area = _pi * radius * radius;
           Console.WriteLine("Area of the circle is " + area);
        }

        ///<summary>
        ///Variable
        ///</summary>
        public void demoVariable()
        {
            bool boolTest = true;
            short byteTest = 19;
            int intTest;
            string stringTest = "David";
            float floatTest;
            int Test = 140000;
            floatTest = 14.5f;
            Console.WriteLine("boolTest = {0}", boolTest);
            Console.WriteLine("byteTest = " + byteTest);
            Console.WriteLine("intTest = " + Test);
            Console.WriteLine("stringTest = " + stringTest);
            Console.WriteLine("floatTest = " + floatTest);
        }

        ///<summary>
        ///Implicitly Variable
        ///</summary>
        public void demoImplicitlyVariable()
        {
            var boolTest = true;
            var byteTest = 19;
            var intTest =140000;
            var stringTest = "David";
            var floatTest = 14.5f;
            Console.WriteLine("boolTest = {0}", boolTest);
            Console.WriteLine("byteTest = " + byteTest);
            Console.WriteLine("intTest = " + intTest);
            Console.WriteLine("stringTest = " + stringTest);
            Console.WriteLine("floatTest = " + floatTest);
        }

        ///<summary>
        ///demo if statement
        ///</summary>
        public void demoIfStatement()
        {
            int yrsOfService = 3;
            double salary = 1500;
            int bonus = 0;
            if (yrsOfService < 5)
            {
                if (salary < 500)
                {
                bonus = 100;
                }
                else
                {
                bonus = 200;
                }
            }
            else
            {
            bonus = 700;
            }
            Console.WriteLine("Bonus amount: " + bonus);
        }

        ///<summary>
        ///demo if statement
        ///</summary>
        public void demoSwitchCase()
        {
            int numOne;
            int numTwo;
            int result = 0;
            Console.WriteLine("(1) Addition");
            Console.WriteLine("(2) Subtraction");
            Console.WriteLine("(3) Multiplication");
            Console.WriteLine("(4) Division");
            int input = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter value one");
            numOne = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter value two");
            numTwo = Convert.ToInt32(Console.ReadLine());
            switch (input)
            {
                case 1:
                    result = numOne + numTwo;
                    break;
                case 2:
                    result = numOne - numTwo;
                    break;
                case 3:
                    result = numOne * numTwo;
                    break;
                    switch (input)
                    {
                        case 1:
                            result = numOne + numTwo;
                            break;
                        case 2:
                            result = numOne - numTwo;
                            break;
                        case 3:
                            result = numOne * numTwo;
                            break;
                        case 4:
                            Console.WriteLine("Do you want to calculatethe quotient or remainder?");
                            Console.WriteLine("(1) Quotient");
                            Console.WriteLine("(2) Remainder");
                            int choice = Convert.ToInt32
                            (Console.ReadLine());
                            switch (choice)
                            {
                                case 1:
                                    result = numOne / numTwo;
                                    break;
                                case 2:
                                    result = numOne % numTwo;
                                    break;
                                default:
                                    Console.WriteLine("Incorrect Choice");
                                    break;
                            }
                            break;
                        default:
                            Console.WriteLine("Incorrect Choice");
                            break;
                    }
                    Console.WriteLine("Result: " + result);
            }
        }

        ///<summary>
        ///demo Loop
        ///</summary>
        public void demoLoop()
        {
            //demo while
            int num = 1;
            Console.WriteLine("");
            while(num <= 11)
            {
                if ((num % 2) == 0)
                {
                Console.WriteLine(num);
                }
                num = num + 1;
            }

            //demo do-while
            int num1 = 1;
            Console.WriteLine("EvenNumbers");
            do
            {
            if ((num1 % 2) == 0)
            {
            Console.WriteLine(num1);
            }
            num1 = num1 + 1;
            } while (num1 <= 11);

            //demo for loop
            Console.WriteLine("Square \t\tCube");
            for (int i = 1, j = 0; i < 11; i++, j++)
            {
                if ((i % 2) == 0)
                {
                    Console.Write("{0} = {1} \t", i, (i * i));
                    Console.Write("{0} = {1} \n", j, (j * j * j));
                }
            }

          
        }

        ///<summary>
        ///Jump Statements
        ///</summary
        public void demoJumpStatements()
        { 
            //demo break
            int numOne = 17;
            int numTwo = 2;
            while(numTwo <= numOne-1)
            {
                if(numOne % numTwo == 0)
                {
                Console.WriteLine("Not a Prime Number");
                break;
                }
                numTwo++;
            }
            if(numTwo == numOne)
                {
                    Console.WriteLine("Prime Number");
                }

            //demo continue
            Console.WriteLine("Even numbers in the range of 1-10");
            for (int i=1; i<=10; i++)
            {
                if (i % 2 != 0)
                {
                continue;
                }
                Console.Write(i + " ");
            }

            //demo goto
            int j = 0;
            display:
            Console.WriteLine("Hello World");
            j++;
            if (j < 5)
                {
                goto display;
                }

            //demo return
            int yrsOfService = 5;
            double salary = 1250;
            double bonus = 0;
            if (yrsOfService <= 5)
            {
            bonus = 50;
            return;
            }
            else
            {
            bonus = salary * 0.2;
            }
            Console.WriteLine("Salary amount: " + salary);
            Console.WriteLine("Bonus amount: " + bonus);
        }

        ///<summary>
        ///Array
        ///</summary>
        public void demoArray()
        {
            //demo Single-dimensional
            string[] students = new string[3] {"James", "Alex", "Fernando"};
            for (int i=0; i<students.Length; i++)
            {
            Console.WriteLine(students[i]);
            }

            //Multi-dimensional Arrays 
            int[,] dimension = new int [4, 5];
            int numOne = 0;
            for (int i=0; i<4; i++)
            {
                for (int j=0; j<5; j++)
                {
                    dimension [i, j] = numOne;
                    numOne++;
                }
            }
            for (int i=0; i<4; i++)
            {
                for (int j=0; j<5; j++)
                    {
                    Console.Write(dimension [i, j] + " ");
                    }
                Console.WriteLine();
            }

            //demo Jagged Arrays
            
            string[][] companies = new string[3][];
            companies[0] = new string[] {"Intel", "AMD"};
            companies[1] = new string[] {"IBM", "Microsoft", "Sun"};
            companies[2] = new string[] {"HP", "Canon", "Lexmark","Epson"};
            for (int i=0; i<companies.GetLength (0); i++)
            {
            Console.Write("List of companies in group " + (i+1) +":\t");
            for (int j=0; j<companies[i].GetLength (0); j++)
            {
            Console.Write(companies [i][j] + " ");
            }
            Console.WriteLine();
            }

            //demo foreach loop
            string[] studentNames = new string[3] { "Ashley", "Joe", "Mikel"};
            foreach (string studName in studentNames)
            {
                Console.WriteLine("Congratulations!! " + studName + " you have been granted an extra leave");
            }

            //demo Using the Array Class
            Array objArray = Array.CreateInstance(typeof (string), 5);
            objArray.SetValue("Marketing", 0);
            objArray.SetValue("Finance", 1);
            objArray.SetValue("Human Resources", 2);
            objArray.SetValue("Information Technology", 3);
            objArray.SetValue("Business Administration", 4);
            for (int i = 0; i<= objArray.GetUpperBound(0); i++)
            {
                Console.WriteLine(objArray.GetValue(i));
            }

            //
            Array objEmployeeDetails = Array.CreateInstance(typeof(string), 2, 3);
            objEmployeeDetails.SetValue("141", 0, 0);
            objEmployeeDetails.SetValue("147", 0, 1);
            objEmployeeDetails.SetValue("154", 0, 2);
            objEmployeeDetails.SetValue("Joan Fuller", 1, 0);
            objEmployeeDetails.SetValue("Barbara Boxen", 1, 1);
            objEmployeeDetails.SetValue("Paul Smith", 1, 2);
            Console.WriteLine("Rank : " + objEmployeeDetails.Rank);
            Console.WriteLine("Employee ID \tName");
            for (int i = 0; i< 1 ; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write(objEmployeeDetails.GetValue(i, j) + "\t\t");
                    Console.WriteLine(objEmployeeDetails.GetValue(i+1, j));
                }
            }
            
        }
        #endregion
    }

   

}

