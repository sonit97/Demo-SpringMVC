package com.totam.day2;

import java.util.Date;
import java.util.Scanner;

public class Management {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Customers cus1 = new Customers();
		Scanner input = new Scanner(System.in);
		System.out.println("Full Name");
		String fullName = input.nextLine();
		System.out.println("Date of Birth");
		String ns = input.nextLine();
		Date date = new Date(ns);
		System.out.println("Phone number");
		String phoneNumber = input.nextLine();
		
		//create instance for Account object
		System.out.println("Account information");
		Accounts account = new Accounts();
		System.out.println("series number");
		String seri = input.nextLine();
		account.setSeriAccount(seri);
		
		System.out.println("number of card");
		String numberAcc = input.nextLine();
		account.setNumberAccount(numberAcc);
		
		Date start = new Date("10/10/2017");
		Date end = new Date("10/10/2018");
		
		//
		Customers cus1 = new Customers(fullName, date, phoneNumber, account);
		System.out.println("customer info");
		System.out.println(cus1.toString());
		//cus1.getFullName()
	}

}
