package com.totam.day2;

import java.util.Date;

public class Customers extends Person {
	private String fullName;
	private Date dateOfBirth;
	private String phoneNumber;
	private Accounts account;
	public static int abc = 5;
	
	public Customers(){
		//int a = 5;
	}
	
	
	
	/**
	 * @param fullName
	 * @param dateOfBirth
	 * @param phoneNumber
	 * @param account
	 */
	public Customers(String fullName, Date dateOfBirth, String phoneNumber,
			Accounts account) {
		super();
	
		this.fullName = fullName;
		this.dateOfBirth = dateOfBirth;
		this.phoneNumber = phoneNumber;
		this.account = account;
	}



	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return fullName;
	}



	/**
	 * @param fullName the fullName to set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}



	/**
	 * @return the dateOfBirth
	 */
	public Date getDateOfBirth() {
		return dateOfBirth;
	}



	/**
	 * @param dateOfBirth the dateOfBirth to set
	 */
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}



	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}



	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}



	/**
	 * @return the account
	 */
	public Accounts getAccount() {
		return account;
	}



	/**
	 * @param account the account to set
	 */
	public void setAccount(Accounts account) {
		this.account = account;
	}



	@Override
	public String toString(){
		return "full name is"+this.getFullName()+"date"+this.dateOfBirth;
	}

}
