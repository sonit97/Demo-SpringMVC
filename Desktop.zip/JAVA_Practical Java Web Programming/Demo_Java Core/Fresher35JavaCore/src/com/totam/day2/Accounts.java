package com.totam.day2;

import java.util.Date;

public class Accounts {
	String seriAccount;
	String numberAccount;
	Date StartDate;
	Date endDate;
	
	public Accounts(){
		
	}
	/**
	 * @param seriAccount
	 * @param numberAccount
	 * @param startDate
	 * @param endDate
	 */
	public Accounts(String seriAccount, String numberAccount, Date startDate,
			Date endDate) {
		super();
		this.seriAccount = seriAccount;
		this.numberAccount = numberAccount;
		StartDate = startDate;
		this.endDate = endDate;
	}
	/**
	 * @return the seriAccount
	 */
	public String getSeriAccount() {
		return seriAccount;
	}
	/**
	 * @param seriAccount the seriAccount to set
	 */
	public void setSeriAccount(String seriAccount) {
		this.seriAccount = seriAccount;
	}
	/**
	 * @return the numberAccount
	 */
	public String getNumberAccount() {
		return numberAccount;
	}
	/**
	 * @param numberAccount the numberAccount to set
	 */
	public void setNumberAccount(String numberAccount) {
		this.numberAccount = numberAccount;
	}
	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return StartDate;
	}
	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(Date startDate) {
		StartDate = startDate;
	}
	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}
	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

}
