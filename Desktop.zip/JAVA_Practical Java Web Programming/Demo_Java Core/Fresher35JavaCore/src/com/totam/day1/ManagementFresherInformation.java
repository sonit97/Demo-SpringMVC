package com.totam.day1;

import java.util.Scanner;

public class ManagementFresherInformation {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Scanner input = new Scanner(System.in);
		System.out.println("enter name:");
		String nameUser = input.nextLine();
		ManagementFresherInformation mn = new ManagementFresherInformation();
		mn.showInfor(nameUser);*/
		int num = 5;
		num = (++num + 3) * 5;
		 //num = ++num * 5;
		 //num = (++num) * 5;
		//int num = (num++) * 5
		 System.out.println(num);
		

	}
	
	/**
	 * show fresher infor ...
	 * @param name
	 */
	public void showInfor(String name) {
		System.out.println("Name is"+name);
	}

}
