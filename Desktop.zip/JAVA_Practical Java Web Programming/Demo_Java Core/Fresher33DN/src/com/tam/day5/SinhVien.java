package com.tam.day5;

import java.util.Date;

public class SinhVien {
	private String maSinhVien;
	private String tenSinhVien;
	private Date ngaySinh;
	private String diaChi;
	
	public SinhVien(){
		
	}

	/**
	 * @param maSinhVien
	 * @param tenSinhVien
	 * @param ngaySinh
	 * @param diaChi
	 */
	public SinhVien(String maSinhVien, String tenSinhVien, Date ngaySinh,
			String diaChi) {
		super();
		this.maSinhVien = maSinhVien;
		this.tenSinhVien = tenSinhVien;
		this.ngaySinh = ngaySinh;
		this.diaChi = diaChi;
	}

	/**
	 * @return the maSinhVien
	 */
	public String getMaSinhVien() {
		return maSinhVien;
	}

	/**
	 * @param maSinhVien the maSinhVien to set
	 */
	public void setMaSinhVien(String maSinhVien) {
		this.maSinhVien = maSinhVien;
	}

	/**
	 * @return the tenSinhVien
	 */
	public String getTenSinhVien() {
		return tenSinhVien;
	}

	/**
	 * @param tenSinhVien the tenSinhVien to set
	 */
	public void setTenSinhVien(String tenSinhVien) {
		this.tenSinhVien = tenSinhVien;
	}

	/**
	 * @return the ngaySinh
	 */
	public Date getNgaySinh() {
		return ngaySinh;
	}

	/**
	 * @param ngaySinh the ngaySinh to set
	 */
	public void setNgaySinh(Date ngaySinh) {
		this.ngaySinh = ngaySinh;
	}

	/**
	 * @return the diaChi
	 */
	public String getDiaChi() {
		return diaChi;
	}

	/**
	 * @param diaChi the diaChi to set
	 */
	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}
	
	@Override
	public String toString(){
		return "Ma sinh vien:"+this.getMaSinhVien()+"\n Ten sinh vien:"+this.getTenSinhVien();
	}

}
