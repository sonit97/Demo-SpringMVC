package com.tam.day2;

import java.util.Date;

public class Employees {
	private String idEmp;
	private String nameEmp;
	private float level;
	private Date dateOfBirth;

	public Employees() {
	}

	/**
	 * @param idEmp
	 * @param nameEmp
	 * @param ageEmp
	 * @param level
	 * @param dateOfBirth
	 */
	public Employees(String idEmp, String nameEmp, int ageEmp, float level,
			Date dateOfBirth) {
		super();
		this.idEmp = idEmp;
		this.nameEmp = nameEmp;
		this.level = level;
		this.dateOfBirth = dateOfBirth;
	}

	/**
	 * @return the idEmp
	 */
	public String getIdEmp() {
		return idEmp;
	}

	/**
	 * @param idEmp
	 *            the idEmp to set
	 */
	public void setIdEmp(String idEmp) {
		this.idEmp = idEmp;
	}

	/**
	 * @return the nameEmp
	 */
	public String getNameEmp() {
		return nameEmp;
	}

	/**
	 * @param nameEmp
	 *            the nameEmp to set
	 */
	public void setNameEmp(String nameEmp) {
		this.nameEmp = nameEmp;
	}

	/**
	 * @return the level
	 */
	public float getLevel() {
		return level;
	}

	/**
	 * @param level
	 *            the level to set
	 */
	public void setLevel(float level) {
		this.level = level;
	}

	/**
	 * @return the dateOfBirth
	 */
	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	/**
	 * @param dateOfBirth
	 *            the dateOfBirth to set
	 */
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	// destructor
	public void destroyEmp() {
		try {
			this.finalize();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		;
	}

	@Override
	public String toString() {
		return "Id:" + this.getIdEmp()+"\n name:"+this.getNameEmp();
	}

}
