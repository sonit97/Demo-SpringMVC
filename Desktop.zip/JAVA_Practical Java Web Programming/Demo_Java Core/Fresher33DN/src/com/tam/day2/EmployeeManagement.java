package com.tam.day2;

import java.util.Date;
import java.util.Scanner;

public class EmployeeManagement {
	public static void main(String[] args) {
		Employees emp = new Employees();
		// System.out.println(emp.nameEmp);
		Scanner input = new Scanner(System.in);
		System.out.println("input id ");
		String id = input.nextLine();
		emp.setIdEmp(id);

		System.out.println("input name");
		String name = input.nextLine();
		emp.setNameEmp(name);
		
		System.out.println("input level ");
		float levels = input.nextFloat();
		emp.setLevel(levels);
		//System.out.println();
		Scanner input1 = new Scanner(System.in);
		
		System.out.println("input date of birth");
		String d = input1.nextLine();
		Date ngaySinh = new Date(d);
		emp.setDateOfBirth(ngaySinh);
		
		System.out.println("information of Employees");
		System.out.println(emp.toString());
		
		}
}
