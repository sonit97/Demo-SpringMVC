package com.tam.day1;

import java.util.Scanner;

/**
 * QuanLy
 * 
 * Version 1.0
 * 
 * Date 08-30-2017
 * 
 * Copyright
 * 
 * Modification Logs DATE AUTHOR DESCRIPTION --------------------------------
 * 08-30-2017 TamTTT3 Create
 */

public class QuanLy {
	private String name;
	public static void main(String[] args) {

		// System.out.println("ok");
		Scanner input = new Scanner(System.in);
		
		/*//enter number
		System.out.println("number 1");
		int num1 = input.nextInt();
		System.out.println("number 1");
		int num2 = input.nextInt();
		
		//create instance of QuanLy class
		QuanLy objQl = new QuanLy();
		objQl.sumNumber(num1, num2);
		
		//*/
		int y=1;
		int kq = y++ + ++y + ++y;
		System.out.println(kq);
	}

	/**
	 * sum of two number
	 * 
	 * @param num1
	 * @param num2
	 */
	public void sumNumber(int num1, int num2) {
		System.out.println("sum of 2 number:"+(num1+num2));
	}

}
