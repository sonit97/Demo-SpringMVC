package com.oop.java;

public class BaoHiemTuVong extends BaoHiem{
	private String truongHopDongBH;
	private float tgToiThieuThamGia;
	
	public BaoHiemTuVong(){
		
	}
	
	public BaoHiemTuVong(String truongHopDongBH, float tgToiThieuThamGia) {
		super();
		this.truongHopDongBH = truongHopDongBH;
		this.tgToiThieuThamGia = tgToiThieuThamGia;
	}
	
	/**
	 * get truong hop dong bao hiem
	 * @return truongHopDongBH
	 */
	public String getTruongHopDongBH() {
		return truongHopDongBH;
	}
	
	/**
	 * set truong hop dong bao hiem
	 * @param truongHopDongBH
	 */
	public void setTruongHopDongBH(String truongHopDongBH) {
		this.truongHopDongBH = truongHopDongBH;
	}
	
	/**
	 * get thoi gian toi thieu tham gia
	 * @return
	 */
	public float getTgToiThieuThamGia() {
		return tgToiThieuThamGia;
	}
	
	/**
	 * set thoi gian toi thieu tham gia
	 * @param tgToiThieuThamGia
	 */
	public void setTgToiThieuThamGia(float tgToiThieuThamGia) {
		this.tgToiThieuThamGia = tgToiThieuThamGia;
	}
	
	
}
