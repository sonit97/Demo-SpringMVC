package com.oop.java;
import java.util.Date;


public class BaoHiemHopDong extends BaoHiem {
	
	private Date tgKetThuc;
	private String sanPhamDiKem;
	
	public BaoHiemHopDong(){
		
	}
	
	public BaoHiemHopDong(Date tgKetThuc, String sanPhamDiKem) {
		super();
		this.tgKetThuc = tgKetThuc;
		this.sanPhamDiKem = sanPhamDiKem;
	}
	
	/**
	 * get thoi gian ket thuc
	 * @return tgKetThuc
	 */
	public Date getTgKetThuc() {
		return tgKetThuc;
	}
	
	/**
	 * set thoi gian ket thuc
	 * @param tgKetThuc
	 */
	public void setTgKetThuc(Date tgKetThuc) {
		this.tgKetThuc = tgKetThuc;
	}
	
	/**
	 * get san pham di kem
	 * @return sanPhamDiKem
	 */
	public String getSanPhamDiKem() {
		return sanPhamDiKem;
	}
	
	/**
	 * san pham di kem
	 * @param sanPhamDiKem
	 */
	public void setSanPhamDiKem(String sanPhamDiKem) {
		this.sanPhamDiKem = sanPhamDiKem;
	}
	
}
