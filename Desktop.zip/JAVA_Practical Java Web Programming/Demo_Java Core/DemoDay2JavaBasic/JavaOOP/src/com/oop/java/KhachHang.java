package com.oop.java;
import java.util.Date;


public class KhachHang {
	
	private String hoTen;
	private Date ngaySinh;
	private String noiThuongTru;
	private String soCMND;
	private BaoHiem baoHiem;
	
	public KhachHang(){
		
	}
	
	public KhachHang(String hoTen, Date ngaySinh, String noiThuongTru,
			String soCMND, BaoHiem baoHiem) {
		super();
		this.hoTen = hoTen;
		this.ngaySinh = ngaySinh;
		this.noiThuongTru = noiThuongTru;
		this.soCMND = soCMND;
		this.baoHiem = baoHiem;
	}
	
	/**
	 * get ho ten
	 * @return hoTen
	 */
	public String getHoTen() {
		return hoTen;
	}
	
	/**
	 * set ho ten
	 * @param hoTen
	 */
	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}
	
	/**
	 * get ngay sinh
	 * @return ngaySinh
	 */
	public Date getNgaySinh() {
		return ngaySinh;
	}
	
	/**
	 * set ngay sinh 
	 * @param ngaySinh
	 */
	public void setNgaySinh(Date ngaySinh) {
		this.ngaySinh = ngaySinh;
	}
	
	/**
	 * get noi thuong tru
	 * @return noiThuongTru
	 */
	public String getNoiThuongTru() {
		return noiThuongTru;
	}
	
	/**
	 * set noi thuong tru
	 * @param noiThuongTru
	 */
	public void setNoiThuongTru(String noiThuongTru) {
		this.noiThuongTru = noiThuongTru;
	}
	
	/**
	 * get so CMND
	 * @return soCMND
	 */
	public String getSoCMND() {
		return soCMND;
	}
	
	/** 
	 * set so CMND
	 * @param soCMND
	 */
	public void setSoCMND(String soCMND) {
		this.soCMND = soCMND;
	}
	
	/**
	 * get bao hiem
	 * @return baoHiem
	 */
	public BaoHiem getBaoHiem() {
		return baoHiem;
	}
	
	/**
	 * set bao hiem
	 * @param baoHiem
	 */
	public void setBaoHiem(BaoHiem baoHiem) {
		this.baoHiem = baoHiem;
	}
	public static void main(String[] args) {
		int x=100; float y=100.0F;
		if(x==y){
		System.out.print("Equal");
		}




	}
	

}
