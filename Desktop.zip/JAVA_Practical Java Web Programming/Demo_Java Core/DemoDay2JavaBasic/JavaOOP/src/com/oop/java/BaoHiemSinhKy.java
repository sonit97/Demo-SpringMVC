package com.oop.java;
import java.util.Date;


public class BaoHiemSinhKy extends BaoHiem{
	
	private Date tgKetThuc;
	private float tgTroCap;
	
	public BaoHiemSinhKy(){
		
	}
	
	public BaoHiemSinhKy(Date tgKetThuc, float tgTroCap) {
		super();
		this.tgKetThuc = tgKetThuc;
		this.tgTroCap = tgTroCap;
	}
	
	/**
	 * get thoi gian ket thuc
	 * @return tgKetThuc
	 */
	public Date getTgKetThuc() {
		return tgKetThuc;
	}
	
	/**
	 * set thoi gian ket thuc
	 * @param tgKetThuc
	 */
	public void setTgKetThuc(Date tgKetThuc) {
		this.tgKetThuc = tgKetThuc;
	}
	
	/**
	 * get thoi gian tro cap
	 * @return tgTroCap
	 */
	public float getTgTroCap() {
		return tgTroCap;
	}
	
	/**
	 * set thoi gian tro cap
	 * @param tgTroCap
	 */
	public void setTgTroCap(float tgTroCap) {
		this.tgTroCap = tgTroCap;
	}
	
}
