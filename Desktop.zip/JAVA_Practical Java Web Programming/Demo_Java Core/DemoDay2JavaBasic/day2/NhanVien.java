package com.totam.day2;

public class NhanVien {
	// thuoc tinh
	private String tenNV;
	private int tuoiNV;
	private String diaChi;

	public NhanVien(String tenNV, int tuoiNV, String diaChi) {
		super();
		this.tenNV = tenNV;
		this.tuoiNV = tuoiNV;
		this.diaChi = diaChi;
	}
	public void huy(){
		try {
			this.finalize();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			System.out.println("dang dc su dung");
		}
	}

	public NhanVien() {

	}

	public String getTenNV() {
		return tenNV;
	}

	public void setTenNV(String tenNV) {
		this.tenNV = tenNV;
	}

	public int getTuoiNV() {
		return tuoiNV;
	}

	public void setTuoiNV(int tuoiNV) {
		this.tuoiNV = tuoiNV;
	}

	public String getDiaChi() {
		return diaChi;
	}

	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}

	@Override
	public String toString() {
		return "Ten La:" + this.getTenNV() + "\n Tuoi la:" + this.getTuoiNV()
				+ "\n Dia chi la" + this.getDiaChi();
	}

}
