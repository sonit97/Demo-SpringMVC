package com.totam.day2.interfac;

public abstract class Animal implements CanMove{

	@Override
	public void run() {
		System.out.println("dung chan chay");
	}

	public abstract int spead();

}
