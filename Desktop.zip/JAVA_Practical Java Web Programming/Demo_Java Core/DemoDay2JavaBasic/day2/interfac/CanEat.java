package com.totam.day2.interfac;

public interface CanEat {
	public void eat();

}
