package com.totam.day2.interfac;

public class Mouse extends Animal implements CanEat{

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int spead() {
		// TODO Auto-generated method stub
		return 0;
	}

}
