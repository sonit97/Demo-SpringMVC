package com.totam.day2;

import java.util.Scanner;

public class QuanLyNhanVien {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Nhap Ten NV:");
		String tenNV = input.nextLine();
		
		System.out.println("Nhap Tuoi");
		int tuoi = input.nextInt();
		
		//tim ham xoa vung dem (cache)
		Scanner input1 = new Scanner(System.in);
		System.out.println("Nhap dia chi");
		String diachi = input1.nextLine();
		
		NhanVien nv1 = new NhanVien(tenNV, tuoi, diachi);
		System.out.println("Thong tin nhan vien la"+nv1.toString());
		//nv1.setTenNV(tenNV);
	}

}
