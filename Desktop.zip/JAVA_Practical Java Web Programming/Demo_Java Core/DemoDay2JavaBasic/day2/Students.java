package com.totam.day2;

import java.util.Date;

public class Students {
	private String tenSV;
	private Date ngaySinh;
	private String diaChi;
		
	public Students(String tenSV, Date ngaySinh, String diaChi) {
		super();
		this.tenSV = tenSV;
		this.ngaySinh = ngaySinh;
		this.diaChi = diaChi;
	}
	public Students(){
		
	}

	public String getTenSV() {
		return tenSV;
	}
	public void setTenSV(String tenSV) {
		this.tenSV = tenSV;
	}
	public Date getNgaySinh() {
		return ngaySinh;
	}
	public void setNgaySinh(Date ngaySinh) {
		this.ngaySinh = ngaySinh;
	}
	public String getDiaChi() {
		return diaChi;
	}
	public void setDiaChi(String diaChi) {
		this.diaChi = diaChi;
	}
	void addNewStudent(){
		Students st = new Students();
		
		//statement
	}

}
