package com.totam.day2.abstrac;

public abstract class Circle extends Shape{
	public Circle(){
		super();
	}

	@Override
	public String nameShape() {
		// TODO Auto-generated method stub
		return "Circle";
	}
	public abstract String getNew();
}
