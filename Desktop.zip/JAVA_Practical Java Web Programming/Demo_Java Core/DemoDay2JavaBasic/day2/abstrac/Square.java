package com.totam.day2.abstrac;

public class Square extends Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("draw square");
		
	}

	@Override
	public String nameShape() {
		// TODO Auto-generated method stub
		return "Square";
	}

}
