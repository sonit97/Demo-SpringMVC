package com.totam.day5;

public class PhongHop {
	private String tenPhong;
	private int Soghe;
	private String vitri;
	public PhongHop(String tenPhong, int soghe, String vitri) {
		super();
		this.tenPhong = tenPhong;
		Soghe = soghe;
		this.vitri = vitri;
	}
	
	public PhongHop(){
		
	}

	public String getTenPhong() {
		return tenPhong;
	}

	public void setTenPhong(String tenPhong) {
		this.tenPhong = tenPhong;
	}

	public int getSoghe() {
		return Soghe;
	}

	public void setSoghe(int soghe) {
		Soghe = soghe;
	}

	public String getVitri() {
		return vitri;
	}

	public void setVitri(String vitri) {
		this.vitri = vitri;
	}
	
	@Override
	public String toString(){
		return "Ten Phong la"+this.getTenPhong()+"\n So ghe la"+this.getSoghe()+"\n Vi tri la"+this.getVitri();
	}
	

}
