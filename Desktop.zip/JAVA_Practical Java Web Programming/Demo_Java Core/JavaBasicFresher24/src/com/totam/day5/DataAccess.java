package com.totam.day5;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DataAccess {
	Connection con = null;
	Statement stmt = null;
	PreparedStatement pstmt= null;
	CallableStatement callstmt = null;
	ResultSet rs = null;
	PhongHop ph;
	ArrayList<PhongHop> ds;
	
	public DataAccess(){
		ds = new ArrayList<>();
	}
	
	public Connection getConnect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=QLPhongHop; username=sa; password=hoaphuc123!");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
	}
	
	 public void addnewPhongHop(PhongHop pHop) throws SQLException {
		/* String sql = "Insert into PhongHop values('"+pHop.getTenPhong()+"',"+pHop.getSoghe()+",'"+pHop.getVitri()+"')";
		 try {
			stmt = getConnect().createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		 
		 String sql = "Insert into Phong values(?,?,?)";
		 try {
			getConnect().setAutoCommit(false);
			pstmt=getConnect().prepareStatement(sql);
			pstmt.setString(1, pHop.getTenPhong());
			pstmt.setInt(2, pHop.getSoghe());
			pstmt.setString(3, pHop.getVitri());
			pstmt.executeUpdate();
			getConnect().commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			getConnect().rollback();
		}
		getConnect().setAutoCommit(true);
	}
	 
	 public ArrayList<PhongHop> getListPhongHop() {
		 try {
			callstmt = getConnect().prepareCall("{call Sp_getPhongHoc()}");
			rs = callstmt.executeQuery();
			 
			while(rs.next()){
				ph = new PhongHop();
				ph.setTenPhong(rs.getString("TenPhong"));
				ph.setSoghe(rs.getInt("SoGhe"));
				ph.setVitri(rs.getString("Vitri"));
				ds.add(ph);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return ds;
		
	}

}
