package com.totam.day2.abstrac;

public class ManagementShape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape s1 = new Square();
	Shape c1 = new Circle1();
		s1.draw();
		System.out.println("name shape"+s1.nameShape());
		
		Circle c1= new Circle1();
		c1.draw();
		System.out.println("name shape"+c1.nameShape());
	}

}
