package com.totam.day2.interfac;

public interface CanMove {
	public static final String PHUONG_TIEN ="Chan";
	public void run();
}
