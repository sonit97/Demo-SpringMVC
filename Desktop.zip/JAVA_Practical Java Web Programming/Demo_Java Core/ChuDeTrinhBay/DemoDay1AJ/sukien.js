function show(){
window.open('https://www.google.com.vn');
}