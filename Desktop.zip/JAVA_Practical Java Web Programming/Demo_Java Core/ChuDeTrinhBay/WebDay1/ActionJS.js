function getInfor(){
		//alert('hello fresher34');
		var kq = prompt('how are you?');
		document.write('<strong style="color:red">'+kq+'</strong>');
	}
	//getInfor();
	function confirmInfor(){
		var kq;
		kq = confirm('are you sure?');
		if(kq==true){
			window.open('Index2.html');
		}else{
			alert('nhap sai');
		}
	}
	function checkValidData(){
		var name = document.getElementById('txtUserName').value;
		var date = document.getElementById('pkNgaySinh').value;
		var msg="";
		var kq=false;
		if(name == "")
		msg+='name is required!'
		else{
		kq = true;
		}
		if(date == "")
		msg+='name is required!'
		else{
		kq = true;
		}
		document.write(msg);
	}