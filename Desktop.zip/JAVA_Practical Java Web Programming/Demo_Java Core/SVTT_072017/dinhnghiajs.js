/*alert('co met khong?');
	alert('ke di');*/
	var ten=prompt('khai ten');
	var a= parseInt(prompt('nhap so a'));
	document.write('ten vua nhap'+ten)
	//openWeb();
	function openWeb(){
	//window.open('Home1.html');
	var ten=document.getElementById('txtHoTen').value;
	if(ten=="")
	document.write('<b style="color:red"> ten phai nhap</b>')
	else
	//window.open('Home1.html');
	alert('check lai');
	}
	
	 function checkCancel(){
	 var kq=confirm('co chac muon xoa khong?');
	 if(kq==true){
		alert('da xoa')
	 }
	 }