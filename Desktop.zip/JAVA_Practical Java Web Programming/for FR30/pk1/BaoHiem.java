package pk1;

public class BaoHiem {
	String tenGoiBH;
	int soTienMua;
	//...
	
}
