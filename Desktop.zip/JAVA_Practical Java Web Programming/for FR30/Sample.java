package Day4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;



public class Sample {
	public static void main(String[] args) {
		
		Student std1 = new Student("SV01", 7, 1990);
		Student std2 = new Student("SV01", 5, 1990);
		Student std3 = new Student("SV01", 8, 1990);
		Student std4 = new Student("SV01", 9, 1990);
		Student std5 = new Student("SV01", 4, 1990);
		Student std6 = new Student("SV01", 8, 1991);
		
		ArrayList<Student> stdList = new ArrayList<>();
		stdList.add(std1);
		stdList.add(std2);
		stdList.add(std3);
		stdList.add(std4);
		stdList.add(std5);
		stdList.add(std6);
		
		Collections.sort(stdList, new StdCompare());
		int i;
		
		for(i = 0 ; i < stdList.size(); i++){
			System.out.println(stdList.get(i).id);
			System.out.println(stdList.get(i).diem);
			System.out.println(stdList.get(i).namSinh);
			System.out.println("=========");
			
		}
		
		System.out.println("");
		
		HashMap<String, Student> hmStD = new HashMap<String, Student>();
		for(i = 0; i < stdList.size(); i++){
			Student std = stdList.get(i);
			if(hmStD.containsKey(std.id)){
				
			}else{
				hmStD.put(std.id, std);
			}
		}
		
	}
	
	static private class StdCompare implements Comparator{
		
		Student std1;
		Student std2;

		@Override
		public int compare(Object o1, Object o2) {
			std1 = (Student) o1;
			std2 = (Student) o2;
			
			if(Integer.compare(std1.diem, std2.diem) != 0){
				return -Integer.compare(std1.diem, std2.diem);
			}else{
				return -Integer.compare(std1.namSinh, std2.namSinh);
			}
				
		}
		
	}
}

class Student{
	String id;
	int diem;
	int namSinh;
	
	public Student(String id, int diem, int namSinh) {
		super();
		this.id = id;
		this.diem = diem;
		this.namSinh = namSinh;
	}
	
	
}
